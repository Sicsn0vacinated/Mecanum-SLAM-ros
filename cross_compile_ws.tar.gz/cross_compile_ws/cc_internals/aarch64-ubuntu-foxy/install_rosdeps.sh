#!/bin/bash
set -euxo pipefail
#[apt] Installation commands:
apt-get install -y python3-pytest ros-foxy-ament-lint-common ros-foxy-std-srvs ros-foxy-rclpy ros-foxy-ament-copyright ros-foxy-rclcpp ros-foxy-sensor-msgs ros-foxy-geometry-msgs ros-foxy-ament-cmake ros-foxy-rviz2 ros-foxy-ament-cmake-python ros-foxy-ament-lint-auto ros-foxy-ament-pep257 ros-foxy-ament-flake8 
