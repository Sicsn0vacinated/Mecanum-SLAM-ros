import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import Command, LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    #Subscript and print out topic cmd_vel
    return LaunchDescription([
        Node(
            package = 'bot_node',
            executable = 'bot_control.py',
            name = 'bot_controller',
            output = 'screen',
            
        )
    ])