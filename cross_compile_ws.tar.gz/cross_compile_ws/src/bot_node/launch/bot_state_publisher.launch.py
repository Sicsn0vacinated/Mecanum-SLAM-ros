import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import Command, LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    #Publish robot_state joint_states and odom

    use_sim_time = LaunchConfiguration('use_sim_time', default='false')

    urdf = os.path.join(
        get_package_share_directory('bot_node'),
        'description',
        'bot_description.urdf'
    )
    """
    #Only publish state and odom not robot desc
    with open(urdf, 'r') as infp:
        robot_desc = infp.read()
    rsp_params = {'robot_description': robot_desc}
    """

    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'robot_description': Command(['xacro ', LaunchConfiguration('model')])}]
    )

    joint_state_publisher_node = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        name='joint_state_publisher',
    )    

    return LaunchDescription([      
        DeclareLaunchArgument(name='model', default_value=urdf,
            description='Absolute path to robot urdf file'),  

        DeclareLaunchArgument(
            'use_sim_time',
            default_value='false',
            description='Use simulation (Gazebo) clock if true'),

        Node(
            package='bot_node',
            executable='bot_odom_publisher.py',
            name='bot_odom_publisher',
            output='screen',
            parameters=[{'use_sim_time': use_sim_time}],
            
        ),
        robot_state_publisher_node,
        joint_state_publisher_node,


    ])

    """
        Node(
            package='bot_node',
            executable='bot_state_publisher',
            name='bot_state_publisher',
            output='screen',
            parameters=[{'use_sim_time': use_sim_time, 'robot_description': robot_desc}],
            arguments=[urdf] #, 'robot_description': robot_desc}],
        ),
    """

    #arguments=[urdf]),