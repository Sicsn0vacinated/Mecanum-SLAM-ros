#starboard encoders CW turn negative: M1 M3
M1 = dict(
    A = 26,
    B = 23,#19,
    pwm = 7,#16,
    en0 = 20,
    en1 = 21,
    
)
M2 = dict(
    A = 6,
    B = 24,
    pwm = 8,
    en0 = 12,
    en1 = 16,
)
M3 = dict(
    A = 5,
    B = 10,
    pwm = 9,
    en0 = 19,
    en1 = 13,
)
M4 = dict(
    A = 14,
    B = 25,
    pwm = 11,
    en0 = 15,
    en1 = 18,
)

#swap the port here
def swap(a, b):
    #tmp = a
    #a = b
    #b = tmp
    return b, a

def starboard_swap(motor):
    motor['A'], motor['B'] = swap(motor['A'], motor['B'])
    ### enable ports swap not checked
    motor['en0'], motor['en1'] = swap(motor['en0'], motor['en1'])
    return motor

starboard_swap(M2)
starboard_swap(M4)
#M2['A'], M2['B'] = swap(M2['A'], M2['B']) 
#M4['A'], M4['B'] = swap(M4['A'], M4['B']) 
#in 2d array format
# listed as WHEEL_PORTS[0]->M1 ...
# M1[i] -> A B en0 en1
WHEEL_PORTS = [[m[key] for key in m] for m in [M1, M2, M3, M4]]