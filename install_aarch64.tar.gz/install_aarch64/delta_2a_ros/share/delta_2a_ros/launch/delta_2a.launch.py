from typing import DefaultDict
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration


def generate_launch_description():

    lidar_port = LaunchConfiguration('port', default='/dev/ttyUSB0')
    laser_frame_id = LaunchConfiguration('laser_frame_id', default='base_laser')
    return LaunchDescription([
        DeclareLaunchArgument(
            'port',
            default_value = lidar_port,
            description = 'Connected port with Lidar'
        ),
        DeclareLaunchArgument(
            'laser_frame_id',
            default_value = laser_frame_id,
            description = 'Robot lidar link defined in the urdf'
        ),
        Node(
            package='delta_2a_ros',
            executable='delta_lidar_node', # delta_lidar_node
            output='screen',
            name='delta_2b_lidar_node',
            parameters = [{'port':lidar_port}, {'laser_frame_id':laser_frame_id}]
        )
    ])